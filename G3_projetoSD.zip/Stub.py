import socket
from typing import Union
import CONSTANT
import json


class StubClient:

    def __init__(self):
        self.s: socket = socket.socket()
        self.s.connect((CONSTANT.ENDERECO_SERVIDOR, CONSTANT.PORTO))

    def grid_size(self):
        msg = CONSTANT.X_MAX
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        valor = self.s.recv(CONSTANT.N_BYTES)
        x_max = int.from_bytes(valor, byteorder="big", signed=True)

        msg = CONSTANT.Y_MAX
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        valor = self.s.recv(CONSTANT.N_BYTES)
        y_max = int.from_bytes(valor, byteorder="big", signed=True)
        return x_max, y_max

    def change_direction(self, direction, nr_player):
        msg = CONSTANT.CHANGE_DIR
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        # mandar a nova direção e o número do jogador
        self.s.send(direction.to_bytes(CONSTANT.N_BYTES, byteorder="big", signed=True))
        self.s.send(nr_player.to_bytes(CONSTANT.N_BYTES, byteorder="big", signed=True))

    def move_player(self, nr_player):
        msg = CONSTANT.MOVE_PLAYER
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        # mandar o número do jogador a mover
        self.s.send(nr_player.to_bytes(CONSTANT.N_BYTES, byteorder="big", signed=True))
        # receber resultado
        #data_rcv = self.s.recv(CONSTANT.N_BYTES)
        #dim = int.from_bytes(data_rcv, byteorder='big', signed=True)
        data_rcv = self.s.recv(CONSTANT.MSG_SIZE)
        result = data_rcv.decode(CONSTANT.CODIFICACAO_STR)
        return result

    def get_players(self):
        msg = CONSTANT.GET_PLAYERS
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        # receber o tamanho do dicionário
        valor = self.s.recv(CONSTANT.N_BYTES)
        dim = int.from_bytes(valor, byteorder='big', signed=True)
        # receber os dados do dicionário e retorná-los
        if dim != 0:
            pl_dict = self.s.recv(dim)
            print(pl_dict)
            players = json.loads(pl_dict)
            return players
        return

    def get_nr_players(self):
        msg = CONSTANT.NR_PLAYERS
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        # receber o número de jogadores e retorná-lo
        valor = self.s.recv(CONSTANT.N_BYTES)
        pl_number = int.from_bytes(valor, byteorder='big', signed=True)
        return pl_number

    def add_player(self, name, x_pos, y_pos):
        msg = CONSTANT.ADD_PLAYER
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        # mandar o nome do novo jogador, dado por input
        self.s.send(len(name).to_bytes(CONSTANT.N_BYTES, byteorder="big", signed=True))
        self.s.send(name.encode(CONSTANT.CODIFICACAO_STR))
        # mandar posições de x e y
        self.s.send(x_pos.to_bytes(CONSTANT.N_BYTES, byteorder="big", signed=True))
        self.s.send(y_pos.to_bytes(CONSTANT.N_BYTES, byteorder="big", signed=True))
        # receber e retornar o nr do jogador criado
        valor = self.s.recv(CONSTANT.N_BYTES)
        number = int.from_bytes(valor, byteorder='big', signed=True)
        return number

    def get_obstacles(self):
        msg = CONSTANT.GET_OBST
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        # receber o tamanho do dicionário
        valor = self.s.recv(CONSTANT.N_BYTES)
        dim = int.from_bytes(valor, byteorder='big', signed=True)
        # receber os dados do dicionário e retorná-los
        obst_dict = self.s.recv(dim)
        obst = json.loads(obst_dict)
        return obst

    def get_nr_obstacles(self):
        msg = CONSTANT.NR_OBST
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        # receber o nr de obstáculos e retorná-lo
        valor = self.s.recv(CONSTANT.N_BYTES)
        nr = int.from_bytes(valor, byteorder='big', signed=True)
        return nr

    def add_first_apple(self):
        msg = CONSTANT.ADD_APPLE
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))

    def start_game(self):
        print("Player wants to start the game")
        msg = CONSTANT.START_GAME
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        # receber mensagem de início
        valor = self.s.recv(CONSTANT.COMMAND_SIZE)
        start_msg = valor.decode(CONSTANT.CODIFICACAO_STR)
        print("Starting the game!")
        return start_msg

    def end_connection(self):
        msg = CONSTANT.END
        self.s.send(msg.encode(CONSTANT.CODIFICACAO_STR))
        # receber confirmação de finalização; fechar o socket caso recebida
        end = self.s.recv(CONSTANT.COMMAND_SIZE)
        if end.decode(CONSTANT.CODIFICACAO_STR) == CONSTANT.END:
            self.s.close()

