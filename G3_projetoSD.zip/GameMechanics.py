# adaptado do ficheiro game_mech disponibilizado nas aulas de laboratório
import time
from random import randint

# definir as constantes para movimento e paço
MOVE_UP = 1
MOVE_RIGHT = 2
MOVE_DOWN = 3
MOVE_LEFT = 4

TYPE_APPLE = "a"
TYPE_BODY = "b"

TIME_STEP = 0.1


class GameMech:

    def __init__(self, x_max: int = 20, y_max: int = 20):
        """
        Construtor da classe GameMech. Criação dos dicionários e listas que guardam a informação sobre o mundo.
        """

        self.x_max = x_max
        self.y_max = y_max

        self.players = dict()
        self.obstacles = dict()
        self.nr_players = 0
        self.nr_obstacles = 0

        self.world = dict()

        # criar chaves no dicionário "world" para cada casa e listas vazias como valor correspondente
        for x in range(self.x_max):
            for y in range(self.y_max):
                self.world[(x, y)] = []

    def add_obstacle(self, obs_type: str, x_pos: int, y_pos: int) -> bool:
        """
        Adicionar um novo obstáculo ao mundo.
        """
        if 0 <= x_pos < self.x_max and 0 <= y_pos < self.y_max:
            nr_obstacle = self.nr_obstacles
            self.obstacles[nr_obstacle] = [obs_type, (x_pos, y_pos)]
            self.world[(x_pos, y_pos)].append(['obstacle', obs_type, nr_obstacle, (x_pos, y_pos)])
            self.nr_obstacles += 1
            return True
        return False

    def move_obstacle(self, obs_type: str, old_x_pos: int, old_y_pos: int, new_x_pos: int, new_y_pos: int) -> bool:
        """
        Mover obstáculo no mundo
        """
        for obs in self.obstacles.items():
            if self.obstacles[obs[0]] != [] and (obs[1][0] == obs_type) and (obs[1][1] == (old_x_pos, old_y_pos)):
                self.obstacles[obs[0]] = [obs_type, (new_x_pos, new_y_pos)]
                self.world[(old_x_pos, old_y_pos)].remove(['obstacle', obs_type, obs[0], (old_x_pos, old_y_pos)])
                self.world[(new_x_pos, new_y_pos)].append(['obstacle', obs_type, obs[0], (new_x_pos, new_y_pos)])
                return True
        return False

    def find_obstacle(self, obs_type, x, y):
        """
        Conferir se uma casa possui um elemento obstáculo de um certo tipo e retorná-lo.
        """
        for e in self.world[(x, y)]:
            if e[0] == 'obstacle' and e[1] == obs_type:
                return e
        return None

    def lose_game(self, nr_player):
        """
        Jogador colide com um obstáculo do tipo 'corpo'. Perde o jogo.
        """
        final_score = self.players[nr_player][4]
        name = self.players[nr_player][0]
        # eliminar corpo do player do mundo
        for body_obj in self.players[nr_player][5].values():
            for obs in self.obstacles.items():
                if obs[1] != []:
                    if (obs[1][0] == body_obj[0]) and (obs[1][1] == (body_obj[1][0], body_obj[1][1])):
                        self.world[(body_obj[1][0], body_obj[1][1])].remove(['obstacle', body_obj[0], obs[0],
                                                                            (body_obj[1][0], body_obj[1][1])])
                        self.obstacles[obs[0]] = []
        # eliminar player do mundo
        self.remove_player(nr_player)
        # retornar resultados
        print(f"Game Over! Jogador {nr_player} ({name}) perdeu. Pontuação Final: {final_score}")
        return f"Game Over! Jogador {nr_player} ({name}) perdeu. Pontuação Final: {final_score}"

    def add_apple(self):
        """
        Adiciona a primeira maçã do jogo
        """
        # verificar se já existem maçãs
        for elem in self.obstacles.values():
            if elem != [] and elem[0] == 'a':
                print(f"Maçã já existe na casa {elem[1]}")
                return
        # adicionar maçã
        self.add_obstacle('a', randint(1, self.x_max - 2), randint(1, self.y_max - 2))

    def eat_apple(self, apple, nr_player):
        """
        Jogador colide com um obstáculo do tipo 'maçã'.
        """
        # destruir a macã
        posx = apple[3][0]
        posy = apple[3][1]
        nr_obstacle = apple[2]
        del self.obstacles[nr_obstacle]
        self.world[(posx, posy)].remove(['obstacle', TYPE_APPLE, nr_obstacle, (posx, posy)])
        # dar ponto ao jogador
        self.players[nr_player][4] += 1
        # aumentar tamanho do jogador
        self.add_body(nr_player, None)
        print(f"Uma maçã foi comida: Player {nr_player} tem agora {self.players[nr_player][4]} pontos")
        # criar nova maçã no mundo
        self.add_apple()

    # ---------- Métodos para o body --------------------------------------------------------------------------------

    def add_body(self, nr_player, last_pos):
        """
        O corpo do jogador aumenta, sendo o novo obstáculo adicionado ao mundo
        """
        if last_pos is not None:
            # adicionar ao dicionário do corpo do jogador uma nova chave com um obstáculo novo
            self.players[nr_player][5][self.players[nr_player][6]] = ['b', (last_pos[0], last_pos[1])]
            # incrementar o nr de obstáculos total do jogador
            self.players[nr_player][6] += 1
            # adicionar o novo obstáculo ao mundo
            self.add_obstacle('b', last_pos[0], last_pos[1])
        else:
            # comparar últimos dois obstáculos
            last_elem = list(self.players[nr_player][5].values())[-1]
            secondlast_elem = list(self.players[nr_player][5].values())[-2]

            if last_elem[1][0] == secondlast_elem[1][0]:
                if last_elem[1][1] > secondlast_elem[1][1]:
                    dif_coord = last_elem[1][1] + 1
                else:
                    dif_coord = last_elem[1][1] - 1
                # adicionar ao dicionário do corpo do jogador uma nova chave com um obstáculo novo
                self.players[nr_player][5][self.players[nr_player][6]] = ['b', (last_elem[1][0], dif_coord)]
                # incrementar o nr de obstáculos total do jogador e adicionar obstáculo ao mundo
                self.players[nr_player][6] += 1
                self.add_obstacle('b', last_elem[1][0], dif_coord)

            elif last_elem[1][1] == secondlast_elem[1][1]:
                if last_elem[1][0] > secondlast_elem[1][0]:
                    dif_coord = last_elem[1][0] + 1
                else:
                    dif_coord = last_elem[1][0] - 1
                # adicionar ao dicionário do corpo do jogador uma nova chave com um obstáculo novo
                self.players[nr_player][5][self.players[nr_player][6]] = ['b', (dif_coord, last_elem[1][1])]
                # incrementar o nr de obstáculos total do jogador e adicionar obstáculo ao mundo
                self.players[nr_player][6] += 1
                self.add_obstacle('b', dif_coord, last_elem[1][1])

            else:
                print("Error: Diagonal movement")

    def move_body(self, nr_player, player_posx: int, player_posy: int):
        """
        Mover o corpo do player consoante o movimento da cabeça
        """
        body = self.players[nr_player][5]
        nr_body_obs = self.players[nr_player][6]

        # mover cada objeto no corpo da cobra
        for i in range(nr_body_obs - 1, -1, -1):
            if i != 0:
                # alterar posicão no mundo e dicionário de objetos
                self.move_obstacle('b', body[i][1][0], body[i][1][1], body[i - 1][1][0], body[i - 1][1][1])
                # alterar posição no corpo da cobra
                body[i] = body[i - 1]
            else:
                # alterar posicão no mundo e dicionário de objetos
                self.move_obstacle('b', body[i][1][0], body[i][1][1], player_posx, player_posy)
                # alterar posição no corpo da cobra
                body[i] = ['b', (player_posx, player_posy)]

    # -------- Métodos para o Player --------------------------------------------------------------------------------

    def add_player(self, name, x_pos: int, y_pos: int) -> int:
        """
        Adicionar um novo jogador ao mundo.
        """
        nr_player = self.nr_players

        tick = int(time.time())
        initial_points = 0

        player_body = dict()
        nr_body_obstacles = 0

        self.players[nr_player] = [name, (x_pos, y_pos), tick, MOVE_RIGHT, initial_points, player_body,
                                   nr_body_obstacles]
        self.world[(x_pos, y_pos)].append(['player', name, nr_player, (x_pos, y_pos)])
        self.nr_players += 1

        self.add_body(nr_player, (x_pos - 1, y_pos))
        self.add_body(nr_player, (x_pos - 2, y_pos))
        self.add_body(nr_player, (x_pos - 3, y_pos))

        return nr_player

    def remove_player(self, nr_player) -> int:
        """
        Remover um jogador do mundo.
        """
        if nr_player <= self.nr_players:
            name = self.players[nr_player][0]
            x_pos, y_pos = self.players[nr_player][1][0], self.players[nr_player][1][1]
            self.world[(x_pos, y_pos)].remove(['player', name, nr_player, (x_pos, y_pos)])
            self.players[nr_player] = []
        return nr_player

    def move_player(self, nr_player):
        """
        Mover o jogador
        """
        if self.players[nr_player] == []:
            return f"Jogador {nr_player} não existe"

        name = self.players[nr_player][0]
        pos_x, pos_y = self.players[nr_player][1][0], self.players[nr_player][1][1]
        tick = self.players[nr_player][2]
        direction = self.players[nr_player][3]
        points = self.players[nr_player][4]
        body = self.players[nr_player][5]
        nr_body_obs = self.players[nr_player][6]
        new_pos_x = pos_x
        new_pos_y = pos_y
        if direction == MOVE_LEFT:
            new_pos_x = pos_x - 1
            new_pos_y = pos_y
        elif direction == MOVE_RIGHT:
            new_pos_x = pos_x + 1
            new_pos_y = pos_y
        elif direction == MOVE_UP:
            new_pos_y = pos_y - 1
            new_pos_x = pos_x
        elif direction == MOVE_DOWN:
            new_pos_y = pos_y + 1
            new_pos_x = pos_x

        # impedir mover-se para fora do limites do mundo
        if new_pos_x < 0 or new_pos_x >= self.x_max or new_pos_y < 0 or new_pos_y >= self.y_max:
            return f"{nr_player}: No Move"

        # mover jogador
        self.players[nr_player] = [name, (new_pos_x, new_pos_y), tick, direction, points, body, nr_body_obs]
        self.world[(pos_x, pos_y)].remove(['player', name, nr_player, (pos_x, pos_y)])
        self.world[(new_pos_x, new_pos_y)].append(['player', name, nr_player, (new_pos_x, new_pos_y)])
        self.move_body(nr_player, pos_x, pos_y)

        # procurar body e perder, se encontrado
        body_obs = self.find_obstacle('b', new_pos_x, new_pos_y)
        if body_obs is not None:
            final_data = self.lose_game(nr_player)
            return final_data

        # procurar maçã e comê-la, se encontrada
        apple = self.find_obstacle('a', new_pos_x, new_pos_y)
        if apple is not None:
            self.eat_apple(apple, nr_player)

        return f"{nr_player}: moved"

    # ------- Métodos "Getter" ----------------------------------------------------------------------------------

    def get_players(self):
        return self.players

    def get_obstacles(self):
        return self.obstacles

    def get_nr_obstacles(self):
        return self.nr_obstacles

    def get_nr_players(self):
        return self.nr_players

    def get_x_max(self):
        return self.x_max

    def get_y_max(self):
        return self.y_max

    # ------- Métodos "Print" ------------------------------------------------------------------------------------

    def print_players(self):
        for p in self.players:
            print("Nr. ", p)
            print("Value:", self.players[p])

    def print_pos(self, x: int, y: int):
        print("(x= ", x, ", y=", y, ") =", self.world[(x, y)])

    def print_world(self):
        for i in range(self.x_max):
            for j in range(self.y_max):
                print("(", i, ",", j, ") =", self.world[(i, j)])

    # ------------------------------------------------------------------------------------------------------------

    def execute(self, move: int, type_exec: str, nr_player: int) -> str:
        """
        Ações do jogador condicionadas pelos ticks.
        """
        if type_exec == "player" and self.players[nr_player] != []:
            name = self.players[nr_player][0]
            pos_x, pos_y = self.players[nr_player][1][0], self.players[nr_player][1][1]
            tick = self.players[nr_player][2]
            old_direction = self.players[nr_player][3]
            points = self.players[nr_player][4]
            body = self.players[nr_player][5]
            nr_body_obs = self.players[nr_player][6]
            new_direction = move

            next_tick = int(time.time() + TIME_STEP)

            forbidden_turns = [[MOVE_UP, MOVE_DOWN], [MOVE_LEFT, MOVE_RIGHT]]
            for elem in forbidden_turns:
                if (old_direction in elem) and (new_direction in elem):
                    return "Could not do a 180º turn"

            if next_tick > tick:
                tick = next_tick
                self.players[nr_player] = [name, (pos_x, pos_y), tick, new_direction, points, body, nr_body_obs]
            else:
                return "Tried to change direction on the same tick"
            return f"**Changed Direction to {new_direction}**"


# Testing the class
if __name__ == '__main__':
    gm = GameMech(10, 10)
    nro_player = gm.add_player('rita', 4, 1)
    print(f"Player created: Player {nro_player}")
    print("Posição Inicial: (4, 1)")
    gm.add_obstacle('a', 7, 1)

    def move_block():
        a = gm.move_player(nro_player)
        time.sleep(0.7)
        print(a)

    move_block()
    move_block()
    move_block()
    move_block()
    move_block()
    b = gm.execute(MOVE_DOWN, "player", 0)  # vai aplicar
    print(b)
    move_block()
    move_block()
    move_block()
    move_block()

    print("VERIFICAÇAO: Print da casa onde o player deve estar:")
    gm.print_pos(9, 5)
    print("body 1")
    gm.print_pos(9, 4)
    print("body 2")
    gm.print_pos(9, 3)
    print("body 3")
    gm.print_pos(9, 2)
    print("body 4")
    gm.print_pos(9, 1)
