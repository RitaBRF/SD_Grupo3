import socket
import CONSTANT
import threading
from typing import Set


class Shared:
    def __init__(self):
        # criar o set de clientes ligados
        self._clients: Set[socket.socket] = set()
        # criar a lock para as threads
        self._clients_lock = threading.Lock()
        # criar semáforo para impedir arranque
        self._clients_control = threading.Semaphore(0)

    def add_client(self, client: socket.socket) -> None:
        """
        Adiciona um cliente à lista de clientes de forma protegida
        :param client:
        :return:
        """
        print("before adding client")
        self._clients_lock.acquire()
        self._clients.add(client)
        self._clients_lock.release()

    def remove_client(self, client_socket: socket.socket) -> None:
        """
        Remove cliente. Se o número de clientes é menor que o número máximo, permite
        a entrada de mais um, abrindo o semáforo para passar apenas 1 (semáforo fica 1)
        :param self:
        :param client_socket:
        :return:
        """
        self._clients_lock.acquire()
        self._clients.remove(client_socket)
        if len(self._clients) < CONSTANT.NR_CLIENTS:
            # pode entrar um cliente
            self._clients_control.release()
        self._clients_lock.release()

    def control_nr_clients(self):
        print("Called control_nr_clients! Nr. clients = ", len(self._clients))
        # verificar se o número de clientes é suficiente
        if len(self._clients) >= CONSTANT.NR_CLIENTS:
            print("Number of clients is", len(self._clients))
            for _ in range(len(self._clients)):
                # cliente pode iniciar o jogo
                self._clients_control.release()
