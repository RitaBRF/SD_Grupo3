import pygame
import Stub

# Defining constants for the moves
M_UP = 1
M_RIGHT = 2
M_DOWN = 3
M_LEFT = 4


class Player(pygame.sprite.DirtySprite):
    def __init__(self, number: int, name: str, pos_x: int, pos_y: int, sq_size: int, *groups):
        super().__init__(*groups)
        self.number = number
        self.name = name
        if self.number == 0:
            self.image = pygame.image.load('./snake_head1.png')
        else:
            self.image = pygame.image.load('./snake_head2.png')
        initial_size = self.image.get_size()
        self.sq_size = sq_size
        size_rate = sq_size / initial_size[0]
        self.new_size = (int(self.image.get_size()[0] * size_rate), int(self.image.get_size()[1] * size_rate))
        self.image = pygame.transform.scale(self.image, self.new_size)
        self.rect = pygame.rect.Rect((pos_x * sq_size, pos_y * sq_size), self.image.get_size())

    def get_size(self):
        return self.new_size

    def update(self, stub: Stub.StubClient):

        key = pygame.key.get_pressed()
        if self.number == 0:
            if key[pygame.K_LEFT]:
                stub.change_direction(M_LEFT, self.number)
            if key[pygame.K_RIGHT]:
                stub.change_direction(M_RIGHT, self.number)
            if key[pygame.K_UP]:
                stub.change_direction(M_UP, self.number)
            if key[pygame.K_DOWN]:
                stub.change_direction(M_DOWN, self.number)
        else:
            if key[pygame.K_a]:
                stub.change_direction(M_LEFT, self.number)
            if key[pygame.K_d]:
                stub.change_direction(M_RIGHT, self.number)
            if key[pygame.K_w]:
                stub.change_direction(M_UP, self.number)
            if key[pygame.K_s]:
                stub.change_direction(M_DOWN, self.number)

        # Keep visible
        self.dirty = 1
