import logging

ENDERECO_SERVIDOR = '127.0.0.1'
PORTO = 8000
COMMAND_SIZE = 5
COMMAND_SIZE_INT = 1
END = "end  "
X_MAX = "max x"
Y_MAX = "max y"
CHANGE_DIR = "chdir"
GET_PLAYERS = "getpl"
NR_PLAYERS = "nrpla"
ADD_PLAYER = "addpl"
MOVE_PLAYER = "movpl"
GET_OBST = "getob"
NR_OBST = "nrobs"
ADD_APPLE = "addap"
START_GAME = "strgm"
MSG_SIZE = 70
N_BYTES = 4
CODIFICACAO_STR = 'utf-8'
NOME_FICHEIRO_LOG = "game-server.log"
NIVEL_LOG = logging.DEBUG
ACCEPT_TIMEOUT = 1
NR_CLIENTS = 2

MOVE_UP = 1
MOVE_RIGHT = 2
MOVE_DOWN = 3
MOVE_LEFT = 4
