import pygame
import Client_Player
import Client_Obstacle
from Stub import StubClient
import time
from random import randint


class GameUI(object):

    def __init__(self, stub: StubClient, grid_size: int = 40):
        # receber dimensão da grid
        dim = stub.grid_size()
        self.x_max = dim[0]
        self.y_max = dim[1]
        self.stub = stub
        # criar o ecrã
        self.width, self.height = self.x_max * grid_size, self.y_max * grid_size
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Snake Game")
        self.clock = pygame.time.Clock()
        # definir cores
        self.grass_color = (167, 209, 61)
        self.grid_color = (213, 255, 107)
        # definir o background
        self.grid_size = grid_size
        self.background = pygame.Surface(self.screen.get_size())
        self.background = self.background.convert()
        self.background.fill(self.grass_color)
        self.screen.blit(self.background, (0, 0))
        # desenhar a grid
        self.draw_grid(self.grid_color)
        pygame.display.update()

    def draw_grid(self, color):
        for x in range(0, self.x_max):
            pygame.draw.line(self.screen, color, (x * self.grid_size, 0), (x * self.grid_size, self.height))
        for y in range(0, self.y_max):
            pygame.draw.line(self.screen, color, (0, y * self.grid_size), (self.width, y * self.grid_size))

    def set_players(self):
        self.pl = self.stub.get_players()
        nr_players = self.stub.get_nr_players()
        self.players = pygame.sprite.LayeredDirty()
        self.players.empty()
        for nr in range(nr_players):
            if self.pl[str(nr)] != []:
                p_x, p_y = self.pl[str(nr)][1][0], self.pl[str(nr)][1][1]
                player = Client_Player.Player(nr, self.pl[str(nr)][0], p_x, p_y, self.grid_size, self.players)
                self.players.add(player)

    def set_obstacles(self):
        self.obs = self.stub.get_obstacles()
        self.obstacles = pygame.sprite.Group()
        nr_obstacles = self.stub.get_nr_obstacles()
        self.obstacles.empty()
        for nr in range(nr_obstacles):
            if str(nr) in self.obs and self.obs[str(nr)] != [] and self.obs[str(nr)][0] == 'b':
                o_x, o_y = self.obs[str(nr)][1][0], self.obs[str(nr)][1][1]
                body = Client_Obstacle.Body(o_x, o_y, self.grid_size, self.obstacles)
                self.obstacles.add(body)
            if str(nr) in self.obs and self.obs[str(nr)] != [] and self.obs[str(nr)][0] == 'a':
                o_x, o_y = self.obs[str(nr)][1][0], self.obs[str(nr)][1][1]
                apple = Client_Obstacle.Apple(o_x, o_y, self.grid_size, self.obstacles)
                self.obstacles.add(apple)

    def move_and_update(self, nr_player_client):
        # move player
        result = self.stub.move_player(nr_player_client)
        # update world
        self.set_players()
        self.set_obstacles()
        return result

    def run(self, stub: StubClient):
        end = False
        tick = time.time()
        # adicionar uma maçã ao mundo, caso este não tenha
        self.stub.add_first_apple()
        # adicionar o client como player
        nome = input("Por favor, qual é o seu nome?")
        nr_player_client = self.stub.add_player(nome, randint(5, 12), randint(1, 18))
        # espera para começo do jogo
        print("À espera de começar o jogo...")
        self.stub.start_game()
        # mostrar os jogadores
        self.set_players()
        # mostrar os obstáculos
        self.set_obstacles()

        while end is False:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    stub.end_connection()
                    end = True
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    stub.end_connection()
                    end = True
            # fazer update ao mundo
            new_tick = time.time()
            if new_tick > tick + 0.4:
                result = self.move_and_update(nr_player_client)
                if result.startswith("Game Over"):
                    print(result)
                    font = pygame.font.SysFont('Arial', 32)
                    txtsurf = font.render(result, True, (0, 0, 0))
                    self.screen.blit(txtsurf, (self.width / 2 - txtsurf.get_width() // 2,
                                               self.height / 2 - txtsurf.get_height() // 2))
                    pygame.display.update()
                tick = new_tick
                print(self.pl)


            # fazer update aos jogadores e aos obstáculos
            self.players.update(self.stub)
            rects = self.players.draw(self.screen)
            self.draw_grid(self.grid_color)
            self.obstacles.draw(self.screen)
            pygame.display.update(rects)
            self.obstacles.clear(self.screen, self.background)
            self.players.clear(self.screen, self.background)

        return
